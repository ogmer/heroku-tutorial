var app = new Vue({
    el: '#app',
    data: {
        addText: '',
        list:[],
    },
    methods: {
        addToDo() {
            if (this.addText) {
                this.list.push({
                    text: this.addText
                });
            }
            this.addText = ''; 
        }
    }
});